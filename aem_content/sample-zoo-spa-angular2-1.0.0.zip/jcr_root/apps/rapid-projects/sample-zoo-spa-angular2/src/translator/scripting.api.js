/*
// uncomment and methods to augment the project's scripting API
// Only use core JavaScript 3.1 methods and, when a DOM element
// is passed, only assert that DOM API level 1 methods of that
// element are available.
// 
// this is to ensure maximum portability of the code as it may,
// in some instances, be ran in a server instead of a browser.
install({
    
    descriptor: {
		
        // method's starting with an "_" are considered
        // "helper" methods and are not shown in the 
        // descriptor UI.
        _getInnerHtml: function _getInnerHtml (element) {

            return element.innerHTML;
            
        },
        
        // a customized "Upload Source: INNERHTML"
        // this method will be shown in the descriptor UI.
        // It is a good practice to start such methods with
        // keywords akin to the descriptor rule property in
        // they are intended to be used (e.g. upload, insertion).
        // It can aslo be useful to name these functions for
        // debugging purposes
        uploadInnerHtml: function uploadInnerHtml (scope) {
            
            var result              = null;
            
            debugger;
            
            // when called from the descriptor, a "scope" is
            // always provided, in which the "target" is the
            // DOM element being transformed to a component.
            // (e.g. an element with the data-designmode attribute)
            if (scope.target) {
                
                // invoke a method of this (in this case, the descriptor) library
                result              = this.api()._getInnerHtml(scope.target);
                
                if (result) {
                                    // borrow a method from the project's JavaScript library
                    result          = this.api('javascript').trim(result);
                
                }
                
            }
            
            return result;
            
        },
        
        // simulating "Insertion: AFTER"
        insertionAfter: function insertAfter (scope) {
            
            debugger;
            
            // leverage RAPID's decriptor library
            this.api()._domInsertListAfter(scope.target, scope.details.insert);
            
            // when used as insertion properties, scripts MUST
            // return a Boolean value to indicate success
            return true;
            
        }
        
    },
    
    javascript: {
        
        greet: function greet (name) {
            
            return 'Hello ' + (name || 'world') + '!';
            
        },

        trim: function trim (value) {
            
            return String(value).replace(/^[\s\uFEFF\xA0]+|[\s\uFEFF\xA0]+$/g, '');
            
        }
        
    }
    
});
/**/