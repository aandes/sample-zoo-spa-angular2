/* (simply delete this line to activate)

// The methods below illustrate to how augment the mirror's 
// translator scripting API (descriptor, javascript, dash etc).
//
// Only use core JavaScript 3.1 API and, when a DOM element
// is passed, only assert that DOM API level 1 methods of that
// element are available. Also, ensure that the methods are
// stateless. Data will not persist from one call to the next.
// 
// This is to ensure maximum portability of the code as it may,
// in some instances, be ran in a server instead of a browser.

install({ descriptor: {
		
    // method's starting with an "_" are considered
    // "helper" methods and are not shown in the 
    // descriptor UI.
    _getInnerHtml: function _getInnerHtml (element) {

        return element.innerHTML;

    },

    // a customized "Insertion: innerHtml"
    // this method will be shown in the descriptor UI
    // but only at the "insertion" field.
    // It can aslo be helpful to name these functions for
    // debugging purposes
    insertInnerHtml: field("insertion", function (scope) {

        var result = null;

        debugger;

        // when called from the descriptor, a "scope" is
        // always provided, in which the "target" is the
        // DOM element being transformed to a component.
        // (e.g. an element with the data-designmode attribute)
        if (scope.target) {

            // this is how to invoke a method of this library
            // (in this case, the descriptor library). Do not
            // make direct method call (e.g. this._getInnerHtml())
            // as they would fail.
            result = this.api()._getInnerHtml(scope.target);

            if (result) {
                
                // use a method from the mirror's javascript library
                result = this.api('javascript').trim(result);

            }

        }

        return result;

    }),

    // simulating "Insertion: AFTER"
    // this method will be shown in the descriptor UI
    // at the all the fields since it is not assigned
    // to a specific field.
    insertAfter: function insertAfter (scope) {

        debugger;

        // leverage RAPID's decriptor library
        this.api()._domInsertListAfter(scope.target, scope.details.insert);

        // when used as insertion properties, scripts MUST
        // return a Boolean value to indicate success
        return true;

    }
        
}});
/**/